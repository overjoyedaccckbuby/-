//
// Created by OverjoyedTang on 2019/12/10.
//


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#define  BUF_SIZE (1024)
unsigned  char fileBuf[BUF_SIZE];
//socket描述符获取
int getSock_fd(const char *IP,const unsigned short port)
{
    int sock_fd;
    int connect_flag;
    struct  sockaddr_in sockselfadd;
    struct hostent *hostself;
    sock_fd = socket(AF_INET,SOCK_STREAM,0);
    if(sock_fd == -1)
    {
        perror("socket");
        exit(1);
    }
    hostself = gethostbyname(IP);
    memset(&sockselfadd,0,sizeof(sockselfadd));
    memcpy(&sockselfadd.sin_addr.s_addr,hostself->h_addr_list[0],4);
    sockselfadd.sin_family = AF_INET;
    sockselfadd.sin_port = htons(port);

    connect_flag = connect(sock_fd,(const struct sockaddr_in*)&sockselfadd, sizeof(sockselfadd));
    if(connect_flag == -1)
    {
        perror("connect");
        exit(1);
    }
    printf("connect success!\n"
           "please send your request according to the help document format\n");

   return sock_fd;
}
//帮助菜单显示
int helpMeun()
{
    printf("\t ---------------------------------------------------------\n"
                   "\t|         Welcome to the file transfer system             |\n"
                   "\t ---------------------------------------------------------\n"
                   "\t|     function    |       the formatting command          |\n"
                   "\t ---------------------------------------------------------\n"
                   "\t|    *filelist    |               filelist:               |\n"
                   "\t ---------------------------------------------------------\n"
                   "\t|     *upload     |  upload:/xxxx/xxxx/filename.filetype  |\n"
                   "\t ---------------------------------------------------------\n"
                   "\t|    *download    | download:/xxxx/xxxx/filename.filetype |\n"
                   "\t ---------------------------------------------------------\n"
                   "\t|      *quit      |                 quit:                 |\n"
                   "\t ---------------------------------------------------------\n"
                   "\t|note:                                                    |\n"
                   "\t|  The ':' in the formatting MSG can't be omitted!!!      |\n"
                   "\t| 'filelist:' is used to view the list in the server.     |\n"
                   "\t|                Designed by overjoyedTang on 2020/01/02  |\n"
                   "\t ---------------------------------------------------------\n");
    return 0;
}
//文件名提取
char *handler_fileName(char *name,const char *allFilePath)
{
    int i,j=0,cnt=0;
    char tmp = '/';
    char *fileName = NULL;
    char *symbol = "/";
    char buf[128];
    char *tmpbuf = NULL;
    while(allFilePath[i]){
        if(allFilePath[i] == '/')
        {
            cnt++;
        }
        i++;
    }
    strncpy(buf,allFilePath,sizeof(buf)-1);
    tmpbuf = buf;
    for(j;j<cnt-1;j++) {
        tmpbuf = strtok_r(tmpbuf, symbol, &fileName);
        tmpbuf = NULL;
    }
    memcpy(name,fileName,strlen(fileName));
    return name;

}
//上传文件
void upload(int client_fd,const char *allFilePath)
{

    FILE *open_flag;
    int send_flag;
    char checkbuf[10];
    unsigned  int filesize;
    int size,netsize;
    int ret;
    int fp;
    //拼接路径和文件名，为fopen函数提供参数
    printf("is opening file:%s to upload\n",allFilePath);
    //传输文件时只能txt文件，此处需要解决传二进制文件
   open_flag = fopen(allFilePath,"r");
    if(open_flag == NULL)
    {
        perror("fopen");
        exit(1);
    }
    //移动游标，统计文件大小
    fseek(open_flag,0,SEEK_END);
    filesize = ftell(open_flag);
    fseek(open_flag,0,SEEK_SET);
    fclose(open_flag);
    //发送文件大小
    if(write(client_fd,(unsigned char *)&filesize,4)!=4)
    {
        perror(" write filesize ");
        exit(1);
    }
    sleep(1);
    //接收验证信息，服务器方验证是否存在同名称文件
    read(client_fd,checkbuf,2);
    if(strncmp(checkbuf,"ok",2))
    {
        printf("A file with the same name already exists on the server!\n");
        printf("the transfer system will shut down....\n");
        sleep(1);
        exit(1);
    }
        //打开文件，开始上传
    fp = open(allFilePath,O_RDONLY);
    ret = read(fp,fileBuf,sizeof(fileBuf));
    while(ret){
        send_flag =send(client_fd,fileBuf,ret,0);
        if(send_flag == -1)
        {
            perror("send file error");
            exit(1);
        }
        ret = read(fp,fileBuf,sizeof(fileBuf));
    }
    sleep(2);
    send_flag = send(client_fd,"quit",sizeof("quit"),0);
    if(send_flag == -1){
        perror("send overflag error");
        exit(1);
    }
    close(fp);
    printf("upload file finished\n");


}
//下载文件
void download(int client_fd,const char *allFilePath)
{
    FILE *open_flag;
    int read_flag;
    int send_flag = 0;
    unsigned  int filesize,fileSize2;
    int size,nodeSize;
    int filenamesize;
    int b;
    char path[256];
    int ret;
    int fp;
    char *checkbuf[10];
    size = read(client_fd,(unsigned char *)&filesize,4);
    if(size != 4)
    {
        printf("file size error!/n");
        exit(1);
    }
    printf("Will receive the file size is:%d bytes\n",filesize);

    printf("save file as:%s\n",allFilePath);
    fp = open(allFilePath,O_CREAT|O_RDWR|O_EXCL,777);
    //检测文件是否存在，检测路径是否有错，并向服务器端发送验证信息
    if(fp == -1)
    {
        printf("This file exists in your save path,or your save path is wrong!\n");
        send_flag =  send(client_fd,"no",2,0);
        if(send_flag == -1)
        {
            printf(" send checkbuf error in function download:");
            exit(1);
        }
        printf("system is about to shut down....\n");
        sleep(1);
        exit(1);
    }
    send_flag = send(client_fd,"ok",2,0);
    if(send_flag == -1)
    {
        printf(" send checkbuf error in function download:");
        exit(1);
    }
    //接收文件
    ret = read(client_fd,fileBuf,sizeof(fileBuf));
    while(ret){

        if(strncmp(fileBuf,"quit",4))
        {
            write(fp,fileBuf,ret);
        }else{
            break;
        }
        ret = read(client_fd,fileBuf,sizeof(fileBuf));

    }
    close(fp);
    open_flag = fopen(allFilePath,"r");
    if(open_flag == NULL)
    {
        perror("fopen");
        exit(1);
    }
    //移动游标，统计文件大小
    fseek(open_flag,0,SEEK_END);
    fileSize2 = ftell(open_flag);
    fseek(open_flag,0,SEEK_SET);
    fclose(open_flag);
    printf("The size of file have been received:%d bytes\n",fileSize2);
    if(fileSize2 == filesize)
    {
        printf("download file success!\n");
    }else{
        printf("download file failed!\n");
    }

}
//文件列表
void fileList(int client_fd)
{
    //文件列表查看
    int recv_flag2;
    char fileNameBuf[1024];
    bzero(fileNameBuf,sizeof(fileNameBuf));
    recv_flag2 = read(client_fd,fileNameBuf, sizeof(fileNameBuf));
    printf("****************FileList****************\n");
    while(recv_flag2){
        if(strncmp(fileNameBuf,"quit",4)){
            printf("-file-：%s\n", fileNameBuf);
            recv_flag2 = read(client_fd, fileNameBuf, sizeof(fileNameBuf));
        }else{
            break;
            }


    }
    printf("******************END*******************\n");


}
int main(int argc,char *argv[]) {
    unsigned short port = 8181;
    char *IP = "47.105.75.154";
    int client_fd;
    char requestBuf[128];
    int send_flag;
    char *cmd;
    char *filename;
    char *pathTofile;
    int send_num;
    int recv_num;
    char checkbuf[64];
    char *allFilePath = NULL;
    //1.显示helpMeun界面
    helpMeun();

    //2.建立连接保持连接
    client_fd = getSock_fd(IP, port);
    if (client_fd == -1) {
        perror("getSock_fd fail");
        exit(1);
    }
    while(1)
    {
        printf("connect server success! you can send your request now:\n");
        //3.发送请求
        memset(requestBuf, 0, sizeof(requestBuf));
        //从键盘获取请求
        fgets(requestBuf, sizeof(requestBuf), stdin);
        //去除获取的回车符号
        requestBuf[strlen(requestBuf)-1] ='\0';

        send_flag = send(client_fd, requestBuf, sizeof(requestBuf), 0);
        if (send_flag == -1) {
            perror("send");
            exit(1);
        }

        //将server中的请求解析函数调用，便于实现对应功能函数的调用 例：文件发送时 客户端为发送 服务器为接收
        cmd = strtok_r(requestBuf, ":", &allFilePath);
        printf("%s\n",allFilePath);
        if (strcmp(cmd, "filelist") == 0) {
            //文件列表函数
            fileList(client_fd);
            continue;

        } else if (strcmp("upload", cmd) == 0) {
            //上传文件，此处为读取发送
            upload(client_fd,allFilePath);
            continue;

        } else if (strcmp("download", cmd) == 0) {
            //下载文件，此处为接收写入
            download( client_fd,allFilePath);
            continue;

        }else if (strncmp("quit", cmd, 4) == 0) {
            //退出，连同服务器一起退出
            printf("is disconnected with the server....\n");
            sleep(1);
            close(client_fd);
            exit(1);
        } else {
            printf("your request MSG is not one of the fomrmatting MSG\n");
            continue;
        }
    }


    //4.文件路径跳转、文件(读取)发送
    //5.再次发送
    //6.发送完成校验
    close(client_fd);

}
/*
//上传源文件的路径跳转、文件状态、文件读取等都在客户端中完成，再对应服务器端的upload函数接收，upload实现数据接收和将文件写入服务器
//下载文件的保存路径跳转、文件写入等都在客户端中完成，再对应服务器的download函数实现接收，download实现文件的读取和发送
//客户端请求解析时，客户端中只用到文件名和文件路径，既是只需要提取字符串中两个':'之后的函数，并创建文件或是路径跳转，路径跳转只需要在客户端通过execl函数实现
//12月11日问题 统计字节数时可能漏统计最后一次read_flag或是write_read_flag,待验证//长连接短链接问题//断开连接问题//文件列表实现问题
//12月12日问题 长连接还是短链接的问题//菜单循环的问题//文件列表中文件大小功能是否实现的问题//监听问题 服务器中是否应该是while(1){accept()}//短链接应用是否正确
//12月16日问题 文件列表函数有逻辑问题/短链接存在问题/已经解决请求解析函数的问题，但是还可以使用数组将值传出/用户任意情景问题//服务器中中send函数的文件描述符有问题
//12月17日问题 文件列表最后一个文件客户端显示两次//
//01月02日问题 以上问题均解决
//designed by overjoyedTang on 2020/1/2
*/