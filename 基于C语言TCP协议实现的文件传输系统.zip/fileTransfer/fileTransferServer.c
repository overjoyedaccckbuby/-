//
// Created by OverjoyedTang on 2019/12/10.
//
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <dirent.h>
#define BUF_SIZE (1024)
unsigned  char fileBuf[BUF_SIZE];
//#include "fileTransfer.h"

int getTcp_fd(unsigned short port)
{
    //获取一个socket描述符建立连接
    int socket_fd;
    int bind_flag;
    struct sockaddr_in Rcvsocketadd;

    socket_fd = socket(AF_INET,SOCK_STREAM,0);
    if(socket_fd == -1)
    {
        perror("socket");
        return -1;
    }

    memset(&Rcvsocketadd,0, sizeof(Rcvsocketadd));
    Rcvsocketadd.sin_family = AF_INET;
    Rcvsocketadd.sin_port = htons(port);
    Rcvsocketadd.sin_addr.s_addr = INADDR_ANY;

    bind_flag = bind(socket_fd,(const struct sockaddr*)&Rcvsocketadd,sizeof(struct sockaddr_in));
    if(bind_flag == -1)
    {
        perror("bind");
        return -1;
    }
    listen(socket_fd,5);
    return socket_fd;
}
/*char *handler_fileName(const char *allFilePath)
{
    int i = 0,j=0,cnt=0;
    char tmp = '/';
    char *fileName = NULL;
    char *symbol = "/";
    char buf[128];
    char *tmpbuf;
    while(allFilePath[i]){
        if(allFilePath[i] == '/')
        {
            cnt++;
        }
        i++;
    }
    strncpy(buf,allFilePath,sizeof(buf));
    tmpbuf = &buf;
    for(j;j<cnt-1;j++) {
        tmpbuf = strtok_r(tmpbuf, symbol, &fileName);
        tmpbuf = NULL;
    }

    //memcpy(name,fileName,sizeof(fileName));
    return fileName;

}*/
char *handler_fileName(const char *allFilePath)
{
    //处理请求，提取文件名
    int i = 0,j=0,cnt=0;
    char tmp = '/';
    char *name = NULL;
    char *symbol = "/";
    char buf[512];
    char *tmpbuf = NULL;
    while(allFilePath[i]){
        if(allFilePath[i] == '/')
        {
            cnt++;
        }
        i++;
    }
    strncpy(buf,allFilePath,sizeof(buf));
    tmpbuf = buf;
    for(j;j<cnt-1;j++) {
        tmpbuf = strtok_r(tmpbuf, symbol, &name);
        tmpbuf = NULL;
    }

    return name;

}
void download(int client_fd,const char *filename,const char *savePath)
{

    FILE *open_flag;
    int send_flag;
    char checkbuf[10];
    char path[256];
    unsigned  int filesize;
    int size,netsize;
    int ret;
    int fp;
    int filenamesize;
    //拼接文件名和保存路径，为open函数提供参数
    filenamesize = strlen(filename);
    sprintf(path,"%.*s%.*s",strlen(savePath),savePath,strlen(filename),filename);
    path[filenamesize+strlen(savePath)+1] ='\0';
    printf("save file to path:%s\n",path);
    printf("is opening file:%s to download:\n",path);
    //传输文件时只能txt文件，此处需要解决传二进制文件
    open_flag = fopen(path,"r");
    if(open_flag == NULL)
    {
        perror("fopen");
        exit(1);
    }
    //统计文件大小
    fseek(open_flag,0,SEEK_END);
    filesize = ftell(open_flag);
    fseek(open_flag,0,SEEK_SET);
    fclose(open_flag);
    //发送文件大小
    if(write(client_fd,(unsigned char *)&filesize,4)!=4)
    {
        perror(" write filesize ");
        exit(1);
    }
    sleep(1);
    //接收客户端的验证信息
    read(client_fd,checkbuf,2);
    if(strncmp(checkbuf,"ok",2))
    {
        printf("The save path in the client is wrong, or the file already exists in the path!\n");
        printf("System is about to shut down....");
        sleep(1);
        exit(1);
    }
    //打开文件并读取发送文件
    fp = open(path,O_RDONLY);
    ret = read(fp,fileBuf,sizeof(fileBuf));
    while(ret){
        if(ret==-1){
            perror("read fail:");
            exit(1);
        }
        send_flag =send(client_fd,fileBuf,ret,0);
        if(send_flag == -1)
        {
            perror("send file error");
            exit(1);
        }
        ret = read(fp,fileBuf,sizeof(fileBuf));
    }
    sleep(1);
    send_flag = send(client_fd,"quit",sizeof("quit"),0);
    if(send_flag == -1)
    {
        perror("send file error");
        exit(1);
    }
    close(fp);
    printf("send file finished\n");


}
void uploadFile(int client_fd,const char *filename,  const char *savePath)
{
    //上传文件
    //上传源文件的路径跳转、文件状态、文件读取等都在客户端中完成，再对应服务器端的upload函数接收，upload实现数据接收和将文件写入服务器
    //此处为接收文件并写入文件
    FILE *open_flag;
    int read_flag;
    int send_flag = 0;
    unsigned  int filesize,fileSize2;
    int size,nodeSize;
    int filenamesize;
    int b;
    char path[256];
    int ret;
    int fp;
    size = read(client_fd,(unsigned char *)&filesize,4);
    if(size != 4)
    {
        printf("file size error!/n");
        exit(1);
    }
    printf("Will receive the file size is:%d bytes\n",filesize);
    //字符串拼接完整路径
    filenamesize = strlen(filename);
    sprintf(path,"%.*s%.*s",strlen(savePath),savePath,strlen(filename),filename);
    path[filenamesize+strlen(savePath)+1] ='\0';
    printf("save file to path:%s\n",path);
    //验证客户端中是否存在同名文件
    fp = open(path,O_CREAT|O_RDWR|O_EXCL,777);
    if(fp == -1)
    {
        size = write(client_fd,"no",2) ;
        if(size != 2)
        {
            perror(write);
            exit(1);
        }
        printf("The user is trying to upload a file with the same name as the file in the server.\nThe system will exit...\n");
        sleep(2);
        exit(1);

    }else{
            size = write(client_fd,"ok",2) ;
        if(size != 2)
        {
            perror(write);
            exit(1);
        }
        }
    //开始接收并写入文件
    ret = read(client_fd,fileBuf,sizeof(fileBuf));
    while(ret){

        if(strncmp(fileBuf,"quit",4))
        {
            write(fp,fileBuf,ret);
        }else{
            break;
        }
        ret = read(client_fd,fileBuf,sizeof(fileBuf));

    }
    close(fp);
    open_flag = fopen(path,"r");
    if(open_flag == NULL)
    {
        perror("fopen");
        exit(1);
    }
    //移动游标，统计文件大小
    fseek(open_flag,0,SEEK_END);
    fileSize2 = ftell(open_flag);
    fseek(open_flag,0,SEEK_SET);
    fclose(open_flag);
    printf("The size of file have been received:%d bytes\n",fileSize2);

}
void fileList(int client_fd, const char  *savaPath)
{
    DIR *saveDir;
    saveDir = opendir(savaPath);
    if(saveDir == -1)
    {
        perror("open savedir error");
        exit(1);
    }
    int send_flag2;
    struct dirent *fileInSavePath;
    memset(&fileInSavePath,0, sizeof(fileInSavePath));
    printf("send fileList....\n");

            while(fileInSavePath= readdir(saveDir))
            {
                send_flag2 = send(client_fd,fileInSavePath->d_name, sizeof(fileInSavePath->d_name),0);
                if(send_flag2 == -1)
                {
                    perror("send fileList");
                    break;
                }
                sleep(1);
                fileInSavePath->d_name[strlen(fileInSavePath->d_name)-1] = 0;


        }
            send(client_fd,"quit",sizeof("quit"),0);
    close(saveDir);
    printf("send fileList finished\n");
    //展示文件列表


}



int main(int argc,char *argv[])
{
    unsigned  short port = 8181;
    int listen_fd;
    int keeplistenFlag;
    char requestBuf[1024];
    int requestRet;
    char *cmd;
    char *allfilepath = NULL;

    //服务器中接收的文件的存储路径
    char *savePath="/home/overjoyed/transfer/";
    //1.建立连接监听信号
    listen_fd = getTcp_fd(port);
    if(listen_fd == -1){
        exit(-1);
    }

    while(1) {
        keeplistenFlag = accept(listen_fd, NULL, NULL);
        if (keeplistenFlag == -1) {
            perror("accept");
            return -1;
        }

        while(1){
            printf("server is listening!\n");
            memset(requestBuf, 0, sizeof(requestBuf));
            //接收用户请求并进行协议解析
            requestRet = recv(keeplistenFlag, requestBuf, sizeof(requestBuf), 0);
            printf("requestBuf:%s\n",requestBuf);
            if (requestRet < 0) {
                perror("recv");
                return -1;
            }
            // 解析请求协议
            cmd = strtok_r(requestBuf, ":", &allfilepath);
            //执行命令对应的函数
            if (strcmp(cmd, "filelist") == 0) {
                    //3.1文件列表
                    fileList(keeplistenFlag, savePath);
                    continue;
               }else if (strcmp("upload", cmd) == 0){
                    //3.2上传文件，此端为接收写入
                    printf("upload process is running....\n");
                    char *filename = handler_fileName(allfilepath);
                    uploadFile(keeplistenFlag,filename,savePath);
                    continue;
                } else if (strcmp("download", cmd) == 0) {
                //下载文件，此端为读取发送
                    printf("download process is running....\n");
                    char *filename2 = handler_fileName(allfilepath);
                    download(keeplistenFlag,filename2,savePath);
                    continue;
                }else if (strncmp("quit", cmd, 4) == 0) {
                    //3.4退出
                    printf("This user is about to exit and the server will be shut down....");
                    sleep(3);
                    close(keeplistenFlag);
                    exit(1);

            }

        }
        close(keeplistenFlag);
    }
    return 0;


}

/*
//服务器请求解析时，只需要将文件名提取出来，然后查找文件（发送 download）或是创建文件（接收  upload）
//上传源文件的路径跳转、文件状态、文件读取等都在客户端中完成，再对应服务器端的upload函数接收，upload实现数据接收和将文件写入服务器
//下载文件的保存路径跳转、文件写入等都在客户端中完成，再对应服务器的download函数实现接收，download实现文件的读取和发送
//客户端请求解析时，客户端中只用到文件名和文件路径，既是只需要提取字符串中两个':'之后的函数，并创建文件或是路径跳转，路径跳转只需要在客户端通过execl函数实现
//12月11日问题 统计字节数时可能漏统计最后一次read_flag或是write_read_flag,待验证//长连接短链接问题//断开连接问题//文件列表实现问题
//12月12日问题 长连接还是短链接的问题//菜单循环的问题//文件列表中文件大小功能是否实现的问题//监听问题 服务器中是否应该是while(1){accept()}//短链接应用是否正确
//12月16日问题 文件列表函数有逻辑问题/短链接存在问题/已经解决请求解析函数的问题，但是还可以使用数组将值传出/用户任意情景问题//服务器中文件传输时send函数的文件描述符有问题
 //12月17日问题  重写keeplisten函数/使用select并发,解决关于select处理短链接的理解错误/select是实现多个客户端同时连接的问题
 //01月02日问题 以上问题均解决
//designed by overjoyedTang on 2020/1/2
 */